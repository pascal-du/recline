import { ANCHOR, TextBuffer, chunks, graphemes } from "./text-sync.js";
import { releaseVelocity, decayStep } from "./scroll-physics.js";

let scannedCode = null, scannedLink = false;
const pairingFragment = new URLSearchParams((location.hash || "").slice(1));
if (pairingFragment.has("pair")) {
  scannedLink = true;
  const candidate = pairingFragment.get("pair");
  if (pairingFragment.getAll("pair").length === 1 && /^[0-9]{6}$/.test(candidate || "")) scannedCode = candidate;
  // Consume the one-use code without leaving it in browser history or URLs.
  window.history.replaceState(null, "", location.pathname + location.search);
}

const $ = id => document.getElementById(id);
const field = $("typing"), pad = $("trackpad"), buffer = new TextBuffer();
const controls = document.querySelectorAll("[data-key], [data-shortcut], [data-click], [data-gesture], #keyboard, #search, #reset-buffer");
let token = null;
try { token = sessionStorage.getItem("recline-token"); } catch { /* Memory-only also works. */ }
let socket = null, ready = false, epoch = "", sequence = 0, offset = 0;
let reconnectTimer = null, retries = 0, lastHeard = 0, manual = false;
const pending = new Map(), gesturePending = new Map();
const useTouchEvents = "ontouchstart" in window;
let serverProtocol = 0;
const gestureNames = { mission_control: "Mission Control", app_expose: "App windows", next_space: "Next Space", previous_space: "Previous Space", back: "Back", forward: "Forward", magnify: "Pinch zoom" };
function gestureFeedback(text) { $("gesture-feedback").textContent = text; }
let composing = false, cancelledComposition = false, compositionTimer = null;
let sensitivity = 1.5, horizontalMode = "pages";
const points = new Map();
let momentum = null, leftHold = null, tapSeries = null;
const leftButton = document.querySelector("[data-click=left]");
let gesture = null, frame = null, motion = { dx: 0, dy: 0 };

function status(label, online = false) {
  $("status").textContent = label;
  $("connection").classList.toggle("online", online);
}
function notice(text) { $("notice").textContent = text; }
function saveToken(value) {
  token = value;
  try { value ? sessionStorage.setItem("recline-token", value) : sessionStorage.removeItem("recline-token"); } catch { /* Memory-only. */ }
}
function resetText(message = "") {
  clearTimeout(compositionTimer);
  if (composing) cancelledComposition = true;
  buffer.reset();
  field.value = ANCHOR;
  field.setSelectionRange(1, 1);
  if (message) notice(message);
}
function clearGestures() {
  releaseLeft(true);
  tapSeries = null;
  endScroll();
  endMagnify(true);
  stopMomentum();
  points.clear(); gesture = null;
  motion = { dx: 0, dy: 0 };
  if (frame !== null) cancelAnimationFrame(frame);
  frame = null;
  pad.classList.remove("active");
}
function enable(value) {
  ready = value;
  controls.forEach(button => { button.disabled = !value; });
  field.disabled = !value;
  if (!value) {
    pending.clear(); gesturePending.clear(); clearGestures(); resetText();
    field.blur();
    $("typing-row").hidden = true;
    $("remote").classList.remove("typing");
    $("keyboard").setAttribute("aria-expanded", "false");
  }
}
function disconnectForSafety(message) {
  enable(false);
  notice(message);
  socket?.close(4000, "Reset connection");
}
function send(event) {
  if (event.type !== "magnify" && gesture?.pinchStarted) {
    endMagnify(true);
    if (gesture) { gesture.ending = true; gesture.moved = true; }
  }
  if (!["move", "button", "click"].includes(event.type) && leftHold) releaseLeft(true);
  if (event.type !== "click" && event.type !== "button" && event.type !== "ping") tapSeries = null;
  if (event.type !== "scroll") stopMomentum();
  if (!ready || socket?.readyState !== WebSocket.OPEN || document.hidden) return false;
  if (socket.bufferedAmount > 16384 || pending.size >= 120) {
    disconnectForSafety("Connection slowed. Unsent input discarded.");
    return false;
  }
  const seq = sequence + 1;
  try {
    socket.send(JSON.stringify({ ...event, epoch, seq, at: Date.now() + offset }));
  } catch {
    disconnectForSafety("Connection lost. Type again after reconnecting.");
    return false;
  }
  sequence = seq;
  pending.set(seq, performance.now());
  if (event.type === "gesture") gesturePending.set(seq, event.action);
  if (event.type === "magnify" && event.phase === "began") gesturePending.set(seq, "magnify");
  return true;
}
function scheduleReconnect() {
  if (!token || manual || document.hidden || reconnectTimer) return;
  const delay = Math.min(10000, 500 * 2 ** Math.min(retries++, 5)) + Math.random() * 200;
  reconnectTimer = setTimeout(() => { reconnectTimer = null; connect(); }, delay);
}
function connect() {
  if (!token || manual || document.hidden) return;
  if (socket && socket.readyState < WebSocket.CLOSING) return;
  status("Connecting…");
  const current = new WebSocket(`${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}/ws`);
  socket = current;
  const authTimer = setTimeout(() => {
    if (!ready && socket === current) current.close(4000, "Connection timeout");
  }, 7000);
  current.addEventListener("open", () => {
    if (socket === current) current.send(JSON.stringify({ type: "auth", token }));
  });
  current.addEventListener("message", event => {
    if (socket !== current) return;
    let message;
    try { message = JSON.parse(event.data); } catch { current.close(); return; }
    lastHeard = performance.now();
    if (message.type === "ready") {
      clearTimeout(authTimer);
      serverProtocol = message.protocol || 0;
      gestureFeedback(serverProtocol >= 3 ? "" : "Restart the Mac server, then reload, for hold and multi-tap controls.");
      epoch = message.epoch; sequence = 0; offset = message.time - Date.now();
      pending.clear(); gesturePending.clear(); clearGestures(); resetText();
      composing = false;
      retries = 0;
      enable(true); status("Connected", true);
      $("pairing").hidden = true;
      $("code").value = "";
      notice("Connected. New typing buffer.");
    } else if (message.type === "ack") {
      pending.delete(message.seq);
      if (gesturePending.has(message.seq)) {
        gestureFeedback(`Mac accepted: ${gestureNames[gesturePending.get(message.seq)]}`);
        gesturePending.delete(message.seq);
      }
    }
  });
  current.addEventListener("close", event => {
    clearTimeout(authTimer);
    if (socket !== current) return;
    const awaitingGesture = gesturePending.size > 0;
    socket = null; enable(false);
    if (awaitingGesture) gestureFeedback(event.code === 1011 ? "Mac input failed. Check Accessibility permission." : event.code === 1008 ? "Mac rejected the command. Restart the server and reload." : "Connection lost before the Mac acknowledged the command.");
    if (event.code === 4001) {
      saveToken(null); $("pairing").hidden = false;
      $("pair-error").textContent = "Pairing expired. Enter the current Mac code.";
      status("Pair again");
    } else {
      status(event.code === 4009 ? "Mac already in use" : "Disconnected");
      notice("Buffer cleared. Input is never replayed.");
      scheduleReconnect();
    }
  });
  current.addEventListener("error", () => current.close());
}

async function pairWithCode(code) {
  const button = $("pair-button");
  button.disabled = true; $("pair-error").textContent = "";
  try {
    const response = await fetch("/pair", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
      signal: AbortSignal.timeout(6000), credentials: "omit", cache: "no-store",
    });
    if (!response.ok) throw new Error(response.status === 429 ? "Too many attempts. Wait 60 seconds." :
      response.status === 409 ? "Another controller is connected. Disconnect it first." :
      response.status === 401 ? "Code expired or incorrect. Scan the current QR code or check the code on your Mac." : "Pairing failed. Check the server address.");
    const result = await response.json();
    saveToken(result.token); manual = false;
    $("code").blur(); connect();
  } catch (error) {
    $("pair-error").textContent = error.name === "TimeoutError" || error.name === "TypeError"
      ? "Cannot reach the Mac. Check your Wi-Fi and server." : error.message;
  } finally { button.disabled = false; }
}
$("pair-form").addEventListener("submit", event => {
  event.preventDefault();
  void pairWithCode($("code").value.trim());
});
$("forget").addEventListener("click", () => {
  manual = true;
  clearTimeout(reconnectTimer); reconnectTimer = null;
  saveToken(null); enable(false); socket?.close(1000, "Unpaired");
  $("settings").open = false; $("pairing").hidden = false;
  $("pair-error").textContent = ""; status("Not paired");
});
setInterval(() => {
  if (!ready || !socket) return;
  const now = performance.now(), oldest = pending.values().next().value;
  if (now - lastHeard > 15000 || (oldest !== undefined && now - oldest > 2000)) {
    disconnectForSafety("Connection stalled. Input discarded.");
  } else if (socket.bufferedAmount < 1024) {
    socket.send(JSON.stringify({ type: "ping" }));
  }
}, 1000);
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    clearTimeout(reconnectTimer); reconnectTimer = null;
    enable(false); socket?.close(1000, "Page backgrounded");
  } else {
    // The old socket might still be closing; its close handler also reconnects.
    connect();
  }
});
window.addEventListener("pagehide", () => { enable(false); socket?.close(1000, "Page hidden"); });
window.addEventListener("pageshow", () => { if (!document.hidden) connect(); });

function flushMotion() {
  if (frame !== null) cancelAnimationFrame(frame);
  frame = null;
  const dx = Math.max(-500, Math.min(500, motion.dx));
  const dy = Math.max(-500, Math.min(500, motion.dy));
  if (dx || dy) send({ type: "move", dx, dy });
  flushTwoFinger();
  flushThreeFinger();
  motion.dx = motion.dy = 0;
}
function queueFrame() { if (frame === null) frame = requestAnimationFrame(flushMotion); }
function nextClickCount(button) {
  const now = performance.now();
  const count = button === "left" && tapSeries && now - tapSeries.time <= 400 && tapSeries.count < 3 ? tapSeries.count + 1 : 1;
  tapSeries = button === "left" ? { time: now, count } : null;
  return count;
}
function click(button) {
  if (leftHold) return;
  flushMotion(); resetText("Typing buffer reset after click.");
  const count = nextClickCount(button);
  send(serverProtocol >= 3 ? { type: "click", button, count } : { type: "click", button });
}
function releaseLeft(cancelled = false) {
  const hold = leftHold;
  leftHold = null;
  if (!hold) return;
  leftButton.classList.remove("held"); leftButton.setAttribute("aria-pressed", "false");
  if (ready) {
    flushMotion();
    send({ type: "button", button: "left", state: "up", count: hold.count });
  }
  if (cancelled) tapSeries = null;
}
function holdLeft(event) {
  event.preventDefault();
  if (!ready || leftHold || (event.pointerType === "mouse" && event.button !== 0)) return;
  if (serverProtocol < 3) { gestureFeedback("Restart the Mac server, then reload, to hold and drag."); return; }
  stopMomentum(); flushMotion(); resetText("Left button held. Move on the trackpad to select.");
  const hold = { pointerId: event.pointerId, count: nextClickCount("left") };
  leftHold = hold;
  if (gesture) gesture.usedButton = true;
  leftButton.setPointerCapture(event.pointerId);
  leftButton.classList.add("held"); leftButton.setAttribute("aria-pressed", "true");
  if (!send({ type: "button", button: "left", state: "down", count: hold.count })) releaseLeft(true);
}

function center() {
  const all = [...points.values()];
  return { x: all.reduce((n, p) => n + p.x, 0) / all.length, y: all.reduce((n, p) => n + p.y, 0) / all.length };
}
function span() {
  const [a, b] = [...points.values()];
  return Math.max(24, Math.hypot(a.x - b.x, a.y - b.y));
}
function stopMomentum() {
  const glide = momentum;
  momentum = null;
  if (!glide) return;
  cancelAnimationFrame(glide.frame);
  if (glide.started) send({ type: "scroll", dx: 0, dy: 0, phase: "momentum_ended" });
}
function startMomentum(samples) {
  const now = performance.now(), velocity = releaseVelocity(samples, now);
  if (!ready || Math.hypot(velocity.vx, velocity.vy) < 0.05) return;
  const glide = { ...velocity, last: now, start: now, started: false, frame: null };
  momentum = glide;
  function tick(time) {
    if (momentum !== glide) return;
    const dt = time - glide.last;
    // A stalled/backgrounded page must never catch up with a large delayed jump.
    if (!ready || document.hidden || dt > 64 || time - glide.start > 2000) { stopMomentum(); return; }
    if (dt <= 0) { glide.frame = requestAnimationFrame(tick); return; }
    const step = decayStep(glide.vx, glide.vy, dt);
    const phase = glide.started ? "momentum_changed" : "momentum_began";
    // Mark before send: congestion/disconnect cleanup can re-enter stopMomentum.
    glide.started = true;
    if (!send({ type: "scroll", dx: step.dx, dy: step.dy, phase })) { stopMomentum(); return; }
    glide.vx = step.vx; glide.vy = step.vy; glide.last = time;
    if (Math.hypot(step.vx, step.vy) < 0.02) { stopMomentum(); return; }
    glide.frame = requestAnimationFrame(tick);
  }
  glide.frame = requestAnimationFrame(tick);
}
function endScroll() {
  if (!gesture?.scrollStarted) return;
  gesture.scrollStarted = false;
  send({ type: "scroll", dx: 0, dy: 0, phase: "ended" });
}
function endMagnify(cancelled = false) {
  if (!gesture?.pinchStarted) return;
  gesture.pinchStarted = false;
  send({ type: "magnify", delta: 0, phase: cancelled ? "cancelled" : "ended" });
}
function gestureAction(action) {
  if (serverProtocol < 2) { gestureFeedback("Restart the Mac server, then reload, for swipe controls."); return false; }
  gestureFeedback(`Sending: ${gestureNames[action]}`);
  resetText("Typing buffer reset after swipe.");
  return send({ type: "gesture", action });
}
function flushThreeFinger() {
  const g = gesture;
  if (!g || g.usedButton || g.ending || g.cancelled || g.swipeSent || g.fingers !== 3 || points.size !== 3) return;
  if (performance.now() - g.threeAt > 1600) return;
  const current = center(), dx = current.x - g.threeStart.x, dy = current.y - g.threeStart.y;
  const horizontal = Math.abs(dx) > Math.abs(dy) * 1.25;
  const vertical = Math.abs(dy) > Math.abs(dx) * 1.25;
  if ((!horizontal && !vertical) || Math.max(Math.abs(dx), Math.abs(dy)) < 40) return;
  const axis = horizontal ? "x" : "y", sign = Math.sign(horizontal ? dx : dy);
  // Require all three fingers to move together, not one moving past two resting fingers.
  if (![...points].every(([id, point]) => (point[axis] - g.threeAnchors.get(id)[axis]) * sign >= 12)) return;
  const action = horizontal ? (dx < 0 ? "next_space" : "previous_space") : (dy < 0 ? "mission_control" : "app_expose");
  g.moved = true;
  if (gestureAction(action)) g.swipeSent = true;
}
function flushTwoFinger() {
  const g = gesture;
  if (!g || g.usedButton || g.ending || g.fingers !== 2 || points.size !== 2) return;
  // Compare finger separation with centroid movement, using the whole batch.
  // Lock one mode until both fingers lift; scroll jitter must not become zoom.
  const current = center();
  const distance = span();
  const separation = Math.abs(distance - g.spanStart);
  const translation = Math.hypot(current.x - g.twoStart.x, current.y - g.twoStart.y);
  if (!g.twoMode) {
    if (separation >= Math.max(8, g.spanStart * 0.06) && separation > translation * 1.35) {
      g.twoMode = "pinch";
      g.moved = true;
      if (serverProtocol < 4) {
        gestureFeedback("Update/restart Recline, then reload, for pinch zoom.");
        return;
      }
      resetText("Typing buffer reset after pinch.");
      gestureFeedback("Pinch zoom — move the Mac pointer over the content.");
      g.pinchStarted = true;
      if (!send({ type: "magnify", delta: 0, phase: "began" })) return;
    } else if (translation >= 4 && translation > separation * 0.75) {
      g.twoMode = "pan";
    } else return;
  }
  if (g.twoMode === "pinch") {
    if (!g.pinchStarted) return;
    const delta = Math.max(-0.25, Math.min(0.25, distance / g.spanLast - 1));
    g.spanLast = distance;
    if (Math.abs(delta) > 0.0001) send({ type: "magnify", delta, phase: "changed" });
    return;
  }
  const totalX = current.x - g.twoStart.x, totalY = current.y - g.twoStart.y;
  if (g.horizontal === "pages") {
    if (!g.axis) {
      if (Math.abs(totalX) >= 8 && Math.abs(totalX) > Math.abs(totalY) * 1.35) g.axis = "x";
      else if (Math.abs(totalY) >= 8 && Math.abs(totalY) > Math.abs(totalX) * 1.35) g.axis = "y";
      else return;
    }
    if (g.axis === "x") {
      if (!g.swipeSent && Math.abs(totalX) >= 48 && performance.now() - g.twoAt <= 1200) {
        g.moved = true;
        if (gestureAction(totalX > 0 ? "back" : "forward")) g.swipeSent = true;
      }
      return;
    }
  }
  if (!g.scrollStarted && Math.hypot(current.x - g.twoStart.x, current.y - g.twoStart.y) < 4) return;
  const dx = g.horizontal === "pages" ? 0 : Math.max(-200, Math.min(200, current.x - g.twoLast.x));
  const dy = Math.max(-200, Math.min(200, current.y - g.twoLast.y));
  if (!dx && !dy) return;
  const last = g.samples.at(-1);
  const previous = g.samples.at(-2);
  // A deliberate reversal should not inherit velocity from the old direction.
  if (previous && (last.x - previous.x) * dx + (last.y - previous.y) * dy < 0) g.samples = [last];
  const now = performance.now();
  g.samples.push({ ...current, t: now });
  g.samples = g.samples.filter(sample => sample.t >= now - 120).slice(-16);
  g.moved = true;
  if (send({ type: "scroll", dx, dy, phase: g.scrollStarted ? "changed" : "began" })) {
    g.scrollStarted = g.didScroll = true;
  }
  g.twoLast = current;
}
function beginPoint(event) {
  event.preventDefault();
  if (!ready || (event.pointerType === "mouse" && event.button !== 0)) return;
  stopMomentum();
  if (!(useTouchEvents && event.pointerType === "touch")) pad.setPointerCapture(event.pointerId);
  points.set(event.pointerId, { x: event.clientX, y: event.clientY, startX: event.clientX, startY: event.clientY });
  if (!gesture) gesture = { start: performance.now(), fingers: 1, moved: false, ending: false };
  if (leftHold) gesture.usedButton = true;
  gesture.fingers = Math.max(gesture.fingers, points.size);
  gesture.last = center();
  // Don't let a queued one-finger delta leak into a two-finger gesture.
  if (points.size > 1) motion = { dx: 0, dy: 0 };
  if (points.size === 2 && gesture.fingers === 2) {
    gestureFeedback("Two fingers detected.");
    gesture.twoStart = gesture.twoLast = center();
    gesture.spanStart = gesture.spanLast = span();
    gesture.twoMode = null; gesture.pinchStarted = false;
    gesture.samples = [{ ...gesture.twoStart, t: performance.now() }];
    gesture.scrollStarted = gesture.didScroll = false;
    gesture.horizontal = horizontalMode; gesture.twoAt = performance.now(); gesture.axis = null;
  } else if (points.size > 2) {
    endScroll();
    endMagnify(true);
    if (points.size === 3 && gesture.fingers === 3) {
      if (document.activeElement === field) {
        field.blur(); $("typing-row").hidden = true;
        $("remote").classList.remove("typing");
        $("keyboard").setAttribute("aria-expanded", "false");
        resetText();
      }
      gestureFeedback("Three fingers detected — swipe together.");
      gesture.threeStart = center(); gesture.threeAt = performance.now();
      gesture.threeAnchors = new Map([...points].map(([id, point]) => [id, { x: point.x, y: point.y }]));
    }
  }
  pad.classList.add("active");
}
function movePoint(event) {
  if (!points.has(event.pointerId) || !gesture) return;
  event.preventDefault();
  const point = points.get(event.pointerId);
  point.x = event.clientX; point.y = event.clientY;
  const current = center();
  const dx = current.x - gesture.last.x, dy = current.y - gesture.last.y;
  gesture.last = current;
  if (Math.hypot(point.x - point.startX, point.y - point.startY) > 6) gesture.moved = true;
  if (gesture.ending || gesture.fingers > 3) return;
  if (points.size === 3) { queueFrame(); return; }
  if (points.size === 2) { queueFrame(); return; }
  if (!gesture.moved) return;
  if (points.size === 1 && gesture.fingers === 1) {
    motion.dx += dx * sensitivity; motion.dy += dy * sensitivity;
  }
  queueFrame();
}
function endPointer(event, cancelled = false) {
  if (!points.has(event.pointerId) || !gesture) return;
  event.preventDefault();
  if (!cancelled) {
    const point = points.get(event.pointerId);
    point.x = event.clientX; point.y = event.clientY;
  }
  // Flush the last complete two-finger sample before removing either point.
  if (!cancelled && (points.size === 2 || points.size === 3)) flushMotion();
  if (!gesture) return;
  endScroll();
  endMagnify(cancelled);
  const finalPoint = points.get(event.pointerId);
  if (Math.hypot(event.clientX - finalPoint.startX, event.clientY - finalPoint.startY) > 6) gesture.moved = true;
  points.delete(event.pointerId);
  if (cancelled) { gesture.moved = true; gesture.cancelled = true; }
  gesture.ending = true; // Suppress the remaining finger after a two-finger lift.
  if (points.size) { gesture.last = center(); return; }
  const tap = !gesture.usedButton && !gesture.moved && performance.now() - gesture.start < 280;
  const fingers = gesture.fingers;
  let samples = !gesture.usedButton && fingers === 2 && gesture.didScroll && !gesture.cancelled ? gesture.samples : null;
  if (samples && gesture.horizontal === "pages") samples = samples.map(sample => ({ ...sample, x: 0 }));
  gesture = null; pad.classList.remove("active");
  if (tap && fingers <= 2) click(fingers === 2 ? "right" : "left");
  else flushMotion();
  if (samples) startMomentum(samples);
}
// Use complete TouchEvent batches on iPhone, without processing the matching
// PointerEvents a second time. Mouse/pen keep the PointerEvent path.
function pointerEvent(event) { return !(useTouchEvents && event.pointerType === "touch"); }
pad.addEventListener("pointerdown", event => { if (pointerEvent(event)) beginPoint(event); });
pad.addEventListener("pointermove", event => { if (pointerEvent(event)) movePoint(event); });
pad.addEventListener("pointerup", event => { if (pointerEvent(event)) endPointer(event); });
pad.addEventListener("pointercancel", event => { if (pointerEvent(event)) { endPointer(event, true); gestureFeedback("Touch cancelled. Try the window controls."); } });
pad.addEventListener("lostpointercapture", event => {
  if (pointerEvent(event) && points.has(event.pointerId)) clearGestures();
});
if (useTouchEvents) {
  const asPoint = touch => ({ pointerId: touch.identifier, pointerType: "touch", clientX: touch.clientX, clientY: touch.clientY, preventDefault() {} });
  pad.addEventListener("touchstart", event => {
    if (event.cancelable) event.preventDefault();
    for (const touch of Array.from(event.changedTouches)) beginPoint(asPoint(touch));
  }, { passive: false });
  pad.addEventListener("touchmove", event => {
    if (event.cancelable) event.preventDefault();
    const touches = Array.from(event.touches).filter(touch => points.has(touch.identifier));
    for (const touch of touches) Object.assign(points.get(touch.identifier), { x: touch.clientX, y: touch.clientY });
    for (const touch of touches) movePoint(asPoint(touch));
  }, { passive: false });
  pad.addEventListener("touchend", event => {
    if (event.cancelable) event.preventDefault();
    for (const touch of Array.from(event.changedTouches)) {
      if (points.has(touch.identifier)) Object.assign(points.get(touch.identifier), { x: touch.clientX, y: touch.clientY });
    }
    for (const touch of Array.from(event.changedTouches)) endPointer(asPoint(touch));
  }, { passive: false });
  pad.addEventListener("touchcancel", () => {
    clearGestures(); gestureFeedback("iOS cancelled the touch. Try the window controls.");
  }, { passive: false });
}
pad.addEventListener("contextmenu", event => event.preventDefault());
for (const type of ["gesturestart", "gesturechange", "gestureend"]) {
  pad.addEventListener(type, event => event.preventDefault(), { passive: false });
}

// Prevent toolbar presses from dismissing Safari's native keyboard.
controls.forEach(button => button.addEventListener("pointerdown", event => event.preventDefault()));
document.querySelectorAll("[data-gesture]").forEach(button => button.addEventListener("click", () => { clearGestures(); gestureAction(button.dataset.gesture); }));
document.querySelectorAll("[data-click]").forEach(button => {
  if (button.dataset.click !== "left") button.addEventListener("click", () => click(button.dataset.click));
});
leftButton.addEventListener("pointerdown", holdLeft);
for (const type of ["pointerup", "pointercancel", "lostpointercapture"]) {
  leftButton.addEventListener(type, event => {
    if (!leftHold || event.pointerId !== leftHold.pointerId) return;
    event.preventDefault(); releaseLeft(type !== "pointerup");
  });
}
// Keyboard/assistive activation still performs a normal click. Ignore the
// compatibility click following a pointer down/up: the Mac already received it.
leftButton.addEventListener("click", event => { if (!event.detail) click("left"); });
function remoteKey(key) {
  flushMotion();
  if (key === "backspace" && buffer.value && !composing) {
    // Update the local suffix too, so the next autocorrection diff is accurate.
    const change = buffer.update(graphemes(buffer.value).slice(0, -1).join(""));
    sendEdit(change);
    field.value = ANCHOR + buffer.value;
    field.setSelectionRange(field.value.length, field.value.length);
  } else {
    resetText(); send({ type: "key", key });
  }
}
document.querySelectorAll("[data-key]").forEach(button => button.addEventListener("click", () => remoteKey(button.dataset.key)));
document.querySelectorAll("[data-shortcut]").forEach(button => button.addEventListener("click", () => {
  flushMotion(); resetText("Typing buffer reset after shortcut.");
  send({ type: "shortcut", key: button.dataset.shortcut });
}));
function showKeyboard() {
  if (!ready) return;
  $("typing-row").hidden = false;
  $("remote").classList.add("typing");
  $("keyboard").setAttribute("aria-expanded", "true");
  field.focus({ preventScroll: true });
  field.setSelectionRange(field.value.length, field.value.length);
}
$("keyboard").addEventListener("click", () => {
  clearGestures();
  if (document.activeElement === field) {
    field.blur(); $("typing-row").hidden = true;
    $("remote").classList.remove("typing");
    $("keyboard").setAttribute("aria-expanded", "false");
  } else showKeyboard();
});
$("search").addEventListener("click", () => {
  flushMotion(); resetText();
  if (send({ type: "shortcut", key: "l" })) showKeyboard();
});
$("reset-buffer").addEventListener("click", () => resetText("New typing buffer. Existing Mac text is unchanged."));

function sendEdit(change) {
  if (!change.delete && !change.text) return true;
  if (change.delete > 128 || change.text.length > 4096) {
    resetText("Edit too large. Please type in smaller sections."); return false;
  }
  const parts = chunks(change.text);
  if (!parts.length) parts.push("");
  for (let i = 0; i < parts.length; i++) {
    if (!send({ type: "edit", delete: i === 0 ? change.delete : 0, text: parts[i] })) {
      resetText(); return false;
    }
  }
  return true;
}
function syncText() {
  if (composing || cancelledComposition || !ready) return;
  let value = field.value;
  // The invisible anchor makes iOS emit deletion events even at an empty buffer.
  if (!value && !buffer.value) {
    send({ type: "key", key: "backspace" }); resetText(); return;
  }
  if (value.startsWith(ANCHOR)) value = value.slice(ANCHOR.length);
  const change = buffer.update(value);
  if (!sendEdit(change)) return;
  if (value.includes("\n") || value.includes("\t")) resetText();
  const wanted = ANCHOR + buffer.value;
  if (field.value !== wanted) {
    field.value = wanted; field.setSelectionRange(wanted.length, wanted.length);
  }
}
field.addEventListener("beforeinput", event => {
  if (composing || event.isComposing) return;
  if (cancelledComposition) {
    // Ignore a late final composition event after a click/shortcut reset. Only a
    // new ordinary edit (or compositionstart) begins a new typing context.
    if (/Composition/.test(event.inputType || "")) {
      if (event.cancelable) event.preventDefault();
      return;
    }
    cancelledComposition = false;
  }
  if (["insertLineBreak", "insertParagraph"].includes(event.inputType) && event.cancelable) {
    event.preventDefault(); remoteKey("enter");
  } else if (event.inputType === "deleteContentBackward" && !buffer.value && event.cancelable) {
    event.preventDefault(); send({ type: "key", key: "backspace" }); resetText();
  } else if (["historyUndo", "historyRedo"].includes(event.inputType) && event.cancelable) {
    event.preventDefault(); resetText("Use ⌘ Z to undo on your Mac.");
  } else if (field.selectionEnd !== field.value.length && event.inputType !== "insertReplacementText") {
    resetText("End-only editing. New typing buffer.");
  }
});
field.addEventListener("input", event => {
  if (cancelledComposition) { field.value = ANCHOR; return; }
  if (["historyUndo", "historyRedo"].includes(event.inputType)) {
    resetText("Use ⌘ Z to undo on your Mac."); return;
  }
  if (!event.isComposing) syncText();
});
field.addEventListener("compositionstart", () => { composing = true; cancelledComposition = false; });
field.addEventListener("compositionend", () => {
  composing = false;
  if (cancelledComposition) {
    resetText();
  } else {
    compositionTimer = setTimeout(syncText, 0);
  }
});
field.addEventListener("keydown", event => {
  // Hardware keyboard support; ordinary text still uses input/composition events.
  if (composing || event.isComposing) return;
  const keys = { Enter: "enter", Escape: "escape", Tab: "tab", ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down" };
  if (event.metaKey || event.ctrlKey) {
    const key = event.key.toLowerCase();
    if ("ltwcvz".includes(key) && key.length === 1) {
      event.preventDefault(); resetText(); send({ type: "shortcut", key });
    }
  } else if (keys[event.key]) {
    event.preventDefault(); remoteKey(keys[event.key]);
  } else if (event.key === "Backspace" && !buffer.value) {
    event.preventDefault(); send({ type: "key", key: "backspace" }); resetText();
  }
});
document.addEventListener("selectionchange", () => {
  if (document.activeElement === field && !composing && !cancelledComposition &&
      (field.selectionStart !== field.value.length || field.selectionEnd !== field.value.length)) {
    resetText("End-only editing. New typing buffer.");
  }
});
field.addEventListener("blur", () => {
  if (!composing) syncText();
});

function viewport() {
  const height = window.visualViewport?.height || window.innerHeight;
  document.documentElement.style.setProperty("--app-height", `${height}px`);
  document.documentElement.classList.toggle("short-viewport", height < 280);
}
window.visualViewport?.addEventListener("resize", viewport);
window.addEventListener("resize", viewport);
window.addEventListener("orientationchange", () => setTimeout(viewport, 200));
try {
  const stored = Number(localStorage.getItem("recline-sensitivity"));
  if (stored >= 0.5 && stored <= 3.5) sensitivity = stored;
} catch { /* Optional setting. */ }
$("sensitivity").value = sensitivity;
function updateSensitivity() {
  sensitivity = Number($("sensitivity").value);
  $("sensitivity-value").value = `${sensitivity.toFixed(1)}×`;
  try { localStorage.setItem("recline-sensitivity", String(sensitivity)); } catch { /* Optional. */ }
}
$("sensitivity").addEventListener("input", updateSensitivity);
try {
  const storedMode = localStorage.getItem("recline-horizontal");
  if (["pages", "scroll"].includes(storedMode)) horizontalMode = storedMode;
} catch { /* Optional setting. */ }
$("horizontal-gesture").value = horizontalMode;
$("horizontal-gesture").addEventListener("change", () => {
  clearGestures();
  horizontalMode = $("horizontal-gesture").value === "scroll" ? "scroll" : "pages";
  try { localStorage.setItem("recline-horizontal", horizontalMode); } catch { /* Optional. */ }
  notice(horizontalMode === "pages" ? "Two fingers: right = Back, left = Forward." : "Two fingers: horizontal scrolling with momentum.");
});
updateSensitivity(); viewport(); resetText();
if (scannedLink) {
  saveToken(null);
  $("pairing").hidden = false;
  if (scannedCode) {
    $("code").value = scannedCode;
    status("Pairing…");
    void pairWithCode(scannedCode);
  } else {
    $("pair-error").textContent = "Invalid QR code. Scan the current code shown by Recline.";
  }
} else if (token) { $("pairing").hidden = true; connect(); }
