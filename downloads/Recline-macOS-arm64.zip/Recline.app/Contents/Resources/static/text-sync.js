// Pure helpers, shared with the Node tests. No network or DOM access here.
export const ANCHOR = "\u200b";
const segmenter = typeof Intl.Segmenter === "function"
  ? new Intl.Segmenter(undefined, { granularity: "grapheme" }) : null;

export function graphemes(text) {
  return segmenter ? Array.from(segmenter.segment(text), part => part.segment) : Array.from(text);
}

export function endEdit(previous, current) {
  const before = graphemes(previous);
  const after = graphemes(current);
  let prefix = 0;
  while (prefix < before.length && prefix < after.length && before[prefix] === after[prefix]) prefix++;
  return { delete: before.length - prefix, text: after.slice(prefix).join("") };
}

export function tail(text) {
  // Keep enough context for predictive replacements without keeping a transcript.
  const parts = graphemes(text);
  let result = "";
  for (let i = parts.length - 1, count = 0; i >= 0 && count < 96; i--, count++) {
    if (parts[i].length + result.length > 256) break;
    result = parts[i] + result;
  }
  return result;
}

export function chunks(text, limit = 256) {
  const result = [];
  let chunk = "";
  for (const char of text) {
    if (chunk.length + char.length > limit) {
      result.push(chunk);
      chunk = "";
    }
    chunk += char;
  }
  if (chunk) result.push(chunk);
  return result;
}

export class TextBuffer {
  constructor() { this.value = ""; }
  reset() { this.value = ""; }
  update(value) {
    const change = endEdit(this.value, value);
    this.value = tail(value);
    return change;
  }
}
