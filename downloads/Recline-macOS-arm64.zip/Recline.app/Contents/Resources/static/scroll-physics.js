// CSS pixels / millisecond. Exponential integration is independent of frame rate.
export const DECAY_MS = 260;
export const MOMENTUM_GAIN = 1.2;
export function releaseVelocity(samples, now) {
  if (samples.length < 2 || now - samples.at(-1).t > 80) return { vx: 0, vy: 0 };
  const recent = samples.filter(sample => sample.t >= now - 100);
  if (recent.length < 2) return { vx: 0, vy: 0 };
  const first = recent[0], last = recent.at(-1), dt = last.t - first.t;
  if (dt < 8) return { vx: 0, vy: 0 };
  const vx = (last.x - first.x) / dt * MOMENTUM_GAIN, vy = (last.y - first.y) / dt * MOMENTUM_GAIN;
  const speed = Math.hypot(vx, vy), scale = speed > 3.6 ? 3.6 / speed : 1;
  return { vx: vx * scale, vy: vy * scale };
}
export function decayStep(vx, vy, dt) {
  const factor = Math.exp(-dt / DECAY_MS);
  return { dx: vx * DECAY_MS * (1 - factor), dy: vy * DECAY_MS * (1 - factor), vx: vx * factor, vy: vy * factor };
}
